# 一维稳态对流扩散方程有限元求解

1. 项目简介
本程序实现一维稳态对流扩散方程的有限元求解，比较 **标准 Galerkin (α=0)**、**迎风格式 (α=1)** 和 **SUPG (α=α_opt)** 三种格式在不同 Peclet 数（0.1 和 3.0）下的表现，并支持网格收敛性研究（附加题）。
  
2. 运行环境
- Python 3.6+
- NumPy, Matplotlib

安装依赖：
```bash
pip install numpy matplotlib

3. 运行方法
基础任务（20 个单元，Pe=0.1 和 3.0）
bash
python advection_diffusion.py
程序将：

打印误差表及矩阵性质分析（Pe=3.0）

生成两张结果图

附加题（网格加密）
在 main() 中取消 nel_list =[10, 20, 40, 80]相关代码的注释，运行后将额外生成两张收敛曲线图。

4. 自定义参数
可在 main() 中修改：
L – 区间长度（默认 1.0）
nel – 单元数（默认 20）
v – 对流速度（默认 1.0）
Pe_list – 需计算的 Peclet 数（默认[0.1, 3.0]）
nel_list – 收敛性研究的单元数列表（默认[10, 20, 40, 80]）

5. 核心函数说明
函数	功能
element_matrix(kappa, v, le, alpha)	返回 2×2 单元矩阵
alpha_supg(Pe)	返回 SUPG 最优 α = coth(Pe) - 1/Pe
solve_advection_diffusion(...)	求解全局问题，返回节点坐标、数值解、精确解
analyze_matrix(K, v, kappa, le)	分析矩阵对称性与正定性（任务4）

6. 预期结果
Pe=0.1：所有格式光滑，误差小，SUPG 节点精确。
Pe=3.0：Galerkin 振荡（误差 ~0.5）；Upwind 无振荡但边界层抹平（误差 ~0.14）；SUPG 节点精确（误差 ~1e-16）。
矩阵性质：对流项导致矩阵不对称、非正定，引发振荡。
网格加密：Galerkin 误差不下降，Upwind 误差不下降，SUPG 始终节点精确。