import numpy as np
import matplotlib.pyplot as plt

# ------------------------------------------------------------
def coth(x):
    """返回 coth(x) = cosh(x)/sinh(x)，处理小 x 避免除零"""
    if abs(x) < 1e-8:
        return 1.0/x + x/3.0   # 级数展开
    exp2x = np.exp(2*x)
    return (exp2x + 1) / (exp2x - 1)

# ------------------------------------------------------------
def element_matrix(kappa, v, le, alpha):
    """
    返回 2x2 单元矩阵
    Ke = kappa_bar/le * [[1, -1], [-1, 1]] + v/2 * [[-1, 1], [-1, 1]]
    其中 kappa_bar = kappa + alpha * v * le / 2
    """
    kappa_bar = kappa + alpha * v * le / 2.0
    diff = (kappa_bar / le) * np.array([[1, -1], [-1, 1]])
    adv  = (v / 2.0) * np.array([[-1, 1], [-1, 1]])
    return diff + adv

# ------------------------------------------------------------
def alpha_supg(Pe):
    """返回 alpha_opt = coth(Pe) - 1/Pe (小 Pe 时返回 Pe/3)"""
    if abs(Pe) < 1e-8:
        return 0.0
    return coth(Pe) - 1.0/Pe

# ------------------------------------------------------------
def solve_advection_diffusion(nel, L, v, kappa, alpha):
    """
    求解一维稳态对流扩散方程
    返回: x (节点坐标), theta (数值解), theta_exact (精确解)
    """
    n_node = nel + 1
    le = L / nel
    K = np.zeros((n_node, n_node))
    
    # 组装总体矩阵
    for e in range(nel):
        i = e
        j = e + 1
        Ke = element_matrix(kappa, v, le, alpha)
        K[i, i] += Ke[0, 0]
        K[i, j] += Ke[0, 1]
        K[j, i] += Ke[1, 0]
        K[j, j] += Ke[1, 1]
    
    # 右端项为零
    F = np.zeros(n_node)
    
    # 边界条件：theta(0)=0, theta(L)=1
    K_mod = K.copy()
    F_mod = F.copy()
    # 左边界 (节点 0)
    K_mod[0, :] = 0.0
    K_mod[0, 0] = 1.0
    F_mod[0] = 0.0
    # 右边界 (节点 n_node-1)
    K_mod[n_node-1, :] = 0.0
    K_mod[n_node-1, n_node-1] = 1.0
    F_mod[n_node-1] = 1.0
    
    theta = np.linalg.solve(K_mod, F_mod)
    
    # 节点坐标
    x = np.linspace(0, L, n_node)
    
    # 精确解（稳定形式，避免溢出）
    a = v / kappa          # = v/kappa
    exp_neg_aL = np.exp(-a * L)
    # 分母 1 - exp(-a*L)
    denom = 1.0 - exp_neg_aL
    # 分子 exp(-a*(L-x)) - exp(-a*L)
    theta_exact = (np.exp(-a * (L - x)) - exp_neg_aL) / denom
    
    return x, theta, theta_exact

# ------------------------------------------------------------
# 最大节点误差
# ------------------------------------------------------------
def max_error(theta_num, theta_exact):
    return np.max(np.abs(theta_num - theta_exact))

# ------------------------------------------------------------
# 绘图
# ------------------------------------------------------------
def plot_all(x, theta_gal, theta_upw, theta_supg, theta_exact, Pe, filename):
    plt.figure(figsize=(8,5))
    plt.plot(x, theta_exact, 'k-', linewidth=2, label='Exact')
    plt.plot(x, theta_gal, 'r-o', label='Galerkin (α=0)')
    plt.plot(x, theta_upw, 'g-s', label='Upwind (α=1)')
    plt.plot(x, theta_supg, 'b-^', label=f'SUPG (α=α_opt)')
    plt.xlabel('x'); plt.ylabel('θ')
    plt.title(f'Advection-Diffusion, cell Pe = {Pe}')
    plt.legend(); plt.grid(True)
    plt.savefig(filename, dpi=150)
    plt.show()

# ------------------------------------------------------------
# 矩阵性质分析 (任务4)
# ------------------------------------------------------------
def analyze_matrix(K, v, kappa, le):
    print("\n" + "="*50)
    print("总体矩阵性质分析 (Pe=3.0, Galerkin α=0)")
    print(f"矩阵形状: {K.shape}")
    # 对称性
    sym_err = np.linalg.norm(K - K.T)
    print(f"对称性检查 (Frobenius范数差): {sym_err:.2e}  {'对称' if sym_err<1e-10 else '不对称'}")
    # 特征值 (检查正定性)
    eigvals = np.linalg.eigvals(K)
    min_eig = np.min(eigvals.real)
    print(f"最小特征值: {min_eig:.4e}  {'正定' if min_eig>0 else '非正定'}")
    # 说明
    print("\n原因：对流项导致矩阵非对称；当 Pe>1 时，对流占优，双线性形式不满足椭圆性，")
    print("系统矩阵可能出现负特征值，造成数值振荡。")

# ------------------------------------------------------------
# 主程序
# ------------------------------------------------------------
def main():
    L = 1.0
    nel = 80
    v = 1.0
    Pe_list = [0.1, 3.0]
    errors = {Pe: {} for Pe in Pe_list}
    
    for Pe in Pe_list:
        le = L / nel
        kappa = v * le / (2.0 * Pe)   # 由 Pe 定义反算 kappa
        print(f"\n--- Pe_cell = {Pe},  kappa = {kappa:.6f},  le = {le:.4f} ---")
        
        # 三种格式
        x, theta_gal, theta_exact = solve_advection_diffusion(nel, L, v, kappa, alpha=0.0)
        _, theta_upw, _ = solve_advection_diffusion(nel, L, v, kappa, alpha=1.0)
        alpha_opt = alpha_supg(Pe)
        _, theta_supg, _ = solve_advection_diffusion(nel, L, v, kappa, alpha=alpha_opt)
        
        # 误差
        err_gal = max_error(theta_gal, theta_exact)
        err_upw = max_error(theta_upw, theta_exact)
        err_supg = max_error(theta_supg, theta_exact)
        errors[Pe]['Galerkin'] = err_gal
        errors[Pe]['Upwind']   = err_upw
        errors[Pe]['SUPG']     = err_supg
        
        print(f"最大节点误差:")
        print(f"  Galerkin (α=0) : {err_gal:.4e}")
        print(f"  Upwind   (α=1) : {err_upw:.4e}")
        print(f"  SUPG     (α={alpha_opt:.4f}) : {err_supg:.4e}")
        
        # 绘图
        plot_all(x, theta_gal, theta_upw, theta_supg, theta_exact, Pe, f"advec_diff_Pe{Pe}.png")
        
        # Pe=3.0 时分析矩阵性质
        if Pe == 3.0:
            # 重新组装不加边界的总体矩阵 (用于分析)
            K_total = np.zeros((nel+1, nel+1))
            for e in range(nel):
                i, j = e, e+1
                Ke = element_matrix(kappa, v, le, alpha=0.0)
                K_total[i,i] += Ke[0,0]; K_total[i,j] += Ke[0,1]
                K_total[j,i] += Ke[1,0]; K_total[j,j] += Ke[1,1]
            analyze_matrix(K_total, v, kappa, le)
    
    # 打印误差汇总表
    print("\n" + "="*50)
    print("误差汇总表 (最大节点误差)")
    print("Pe\tGalerkin\tUpwind\t\tSUPG")
    for Pe in Pe_list:
        print(f"{Pe}\t{errors[Pe]['Galerkin']:.4e}\t{errors[Pe]['Upwind']:.4e}\t{errors[Pe]['SUPG']:.4e}")

if __name__ == "__main__":
    main()