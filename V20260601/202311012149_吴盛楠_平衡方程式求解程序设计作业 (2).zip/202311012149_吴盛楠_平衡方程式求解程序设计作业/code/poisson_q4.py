import numpy as np
import time
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import spsolve
import matplotlib.pyplot as plt

# ========== 1. 参数设置 ==========
nx, ny = 500, 500  # 网格划分数
Lx, Ly = 1.0, 1.0

def u_exact(x, y):
    return np.sin(np.pi*x) * np.sin(np.pi*y)

def f_source(x, y):
    return 2 * np.pi**2 * np.sin(np.pi*x) * np.sin(np.pi*y)

# ========== 2. 网格生成 ==========
x = np.linspace(0, Lx, nx+1)
y = np.linspace(0, Ly, ny+1)
X, Y = np.meshgrid(x, y)
nodes = np.vstack([X.ravel(), Y.ravel()]).T
n_nodes = (nx+1)*(ny+1)
n_elem = nx * ny

# 单元连接（Q4）
elements = []
for j in range(ny):
    for i in range(nx):
        n0 = j*(nx+1) + i
        n1 = n0 + 1
        n2 = n0 + (nx+1) + 1
        n3 = n0 + (nx+1)
        elements.append([n0, n1, n2, n3])
elements = np.array(elements)

# 输出基本信息
print("=" * 60)
print("Poisson 方程有限元求解 (Q4单元)")
print(f"单元类型: Q4 (双线性四边形)")
print(f"网格: {nx} x {ny} = {n_elem} 个单元")
print(f"节点数: {n_nodes}")
print(f"未知自由度数: {n_nodes} (每个节点一个自由度)")

# ========== 3. 组装（计时） ==========
total_start = time.time()

t_assembly_start = time.time()
K = lil_matrix((n_nodes, n_nodes), dtype=float)
F = np.zeros(n_nodes)

gp = [-0.5773502691896257, 0.5773502691896257]
gw = [1.0, 1.0]

for e in elements:
    coord = nodes[e]
    Ke = np.zeros((4,4))
    Fe = np.zeros(4)
    for i in range(2):
        xi = gp[i]
        wi = gw[i]
        for j in range(2):
            eta = gp[j]
            wj = gw[j]
            N = np.array([
                0.25*(1-xi)*(1-eta),
                0.25*(1+xi)*(1-eta),
                0.25*(1+xi)*(1+eta),
                0.25*(1-xi)*(1+eta)
            ])
            dN_dxi = 0.25 * np.array([
                [-(1-eta), -(1-xi)],
                [ (1-eta), -(1+xi)],
                [ (1+eta),  (1+xi)],
                [-(1+eta),  (1-xi)]
            ])
            J = np.zeros((2,2))
            for k in range(4):
                J[0,0] += dN_dxi[k,0] * coord[k,0]
                J[0,1] += dN_dxi[k,0] * coord[k,1]
                J[1,0] += dN_dxi[k,1] * coord[k,0]
                J[1,1] += dN_dxi[k,1] * coord[k,1]
            detJ = np.linalg.det(J)
            invJ = np.linalg.inv(J)
            dN_dxy = dN_dxi @ invJ
            Ke += (dN_dxy @ dN_dxy.T) * detJ * wi * wj
            x_phys = N @ coord[:,0]
            y_phys = N @ coord[:,1]
            f_val = f_source(x_phys, y_phys)
            Fe += N * f_val * detJ * wi * wj
    for i, gi in enumerate(e):
        for j, gj in enumerate(e):
            K[gi, gj] += Ke[i, j]
        F[gi] += Fe[i]

t_assembly = time.time() - t_assembly_start
print(f"装配时间: {t_assembly:.3f} 秒")
print(f"总体矩阵非零元个数: {K.nnz}")

# ========== 4. 边界条件处理（计时） ==========
t_bc_start = time.time()
tol = 1e-10
boundary = []
for i, (xc, yc) in enumerate(nodes):
    if xc < tol or xc > Lx-tol or yc < tol or yc > Ly-tol:
        boundary.append(i)
fixed = np.array(boundary)
free = np.setdiff1d(np.arange(n_nodes), fixed)
K_ff = K[np.ix_(free, free)].tocsr()
F_f = F[free]
t_bc = time.time() - t_bc_start
print(f"边界条件处理时间: {t_bc:.3f} 秒")
print(f"未知自由度数（缩减后）: {len(free)}")

# ========== 5. 求解（计时） ==========
t_solve_start = time.time()
solver_name = "scipy.sparse.linalg.spsolve (SuperLU)"
u_f = spsolve(K_ff, F_f)
t_solve = time.time() - t_solve_start
print(f"求解器: {solver_name}")
print(f"求解时间: {t_solve:.3f} 秒")

# 总时间
total_time = time.time() - total_start
print(f"总时间: {total_time:.3f} 秒")

# 重构完整解
u = np.zeros(n_nodes)
u[free] = u_f
u[fixed] = 0.0

# ========== 6. 后处理：残差与误差 ==========
res_f = F_f - K_ff @ u_f
rel_res = np.linalg.norm(res_f) / (np.linalg.norm(F_f) + 1e-15)
print(f"缩减系统相对残差: {rel_res:.2e}")

u_exact_nodes = u_exact(nodes[:,0], nodes[:,1])
max_err = np.max(np.abs(u - u_exact_nodes))
l2_err = np.sqrt(np.sum((u - u_exact_nodes)**2) / (np.sum(u_exact_nodes**2) + 1e-15))
print(f"节点最大误差: {max_err:.4e}")
print(f"离散L2相对误差: {l2_err:.4e}")

# ========== 7. 绘图 ==========
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

figname_solution = f'poisson_solution_{nx}x{ny}.png'
figname_error = f'poisson_error_{nx}x{ny}.png'

plt.figure(figsize=(12,5))
plt.subplot(1,2,1)
plt.tricontourf(nodes[:,0], nodes[:,1], u, levels=20, cmap='viridis')
plt.colorbar(label='u_h')
plt.axhline(y=0.5, color='red', linestyle='--', linewidth=1, label='y=0.5')
plt.axvline(x=0.5, color='red', linestyle='--', linewidth=1, label='x=0.5')
plt.xlabel('x')
plt.ylabel('y')
plt.title(f'数值解 (Q4, {nx}x{ny}网格)')
plt.legend()
plt.axis('equal')

plt.subplot(1,2,2)
err = np.abs(u - u_exact_nodes)
plt.tricontourf(nodes[:,0], nodes[:,1], err, levels=20, cmap='Reds')
plt.colorbar(label='|u_h - u_exact|')
plt.axhline(y=0.5, color='blue', linestyle='--', linewidth=1, label='y=0.5')
plt.axvline(x=0.5, color='blue', linestyle='--', linewidth=1, label='x=0.5')
plt.xlabel('x')
plt.ylabel('y')
plt.title('绝对误差')
plt.legend()
plt.axis('equal')
plt.tight_layout()
plt.savefig(figname_solution, dpi=150)
plt.show()

print(f"图片已保存: {figname_solution}")