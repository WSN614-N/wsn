import numpy as np
import time
from scipy.sparse import diags, csr_matrix
from scipy.sparse.linalg import spsolve

# 尝试导入 pypardiso
try:
    from pypardiso import spsolve as pardsolve
    HAS_PARDISO = True
except ImportError:
    HAS_PARDISO = False
    print("pypardiso 未安装，只使用 scipy.sparse.spsolve")

# 参数设置
n = 5000  # 自由度数（可以根据电脑内存调整，建议 5000~20000）
print(f"矩阵阶数: {n}")

# 1. 生成稀疏对称正定矩阵（三对角，代表一维泊松方程有限元离散）
# 主对角线为 2，次对角线为 -1
diagonals = [-1, 2, -1]
offsets = [-1, 0, 1]
K_sparse = diags(diagonals, offsets, shape=(n, n), format='csr', dtype=np.float64)
# 转换为 CSR 格式（已经是）
R = np.ones(n)  # 右端项全1

# 输出非零元个数
nnz = K_sparse.nnz
print(f"非零元个数: {nnz}")
print(f"稀疏度: {nnz / (n*n):.2%}")

# 2. 调用 scipy.sparse.linalg.spsolve
print("\n" + "="*50)
print("求解器: scipy.sparse.linalg.spsolve (SuperLU)")
t0 = time.time()
a1 = spsolve(K_sparse, R)
t1 = time.time()
time_sp = t1 - t0

# 计算残差
r1 = R - K_sparse @ a1
rel_res1 = np.linalg.norm(r1) / np.linalg.norm(R)
print(f"求解时间: {time_sp:.4f} 秒")
print(f"相对残差: {rel_res1:.2e}")

# 3. 如果可用，调用 pypardiso
if HAS_PARDISO:
    print("\n" + "="*50)
    print("求解器: pypardiso (Intel MKL PARDISO)")
    t0 = time.time()
    a2 = pardsolve(K_sparse, R)
    t1 = time.time()
    time_par = t1 - t0
    r2 = R - K_sparse @ a2
    rel_res2 = np.linalg.norm(r2) / np.linalg.norm(R)
    print(f"求解时间: {time_par:.4f} 秒")
    print(f"相对残差: {rel_res2:.2e}")
    
    # 对比两种求解器的结果（应几乎一致）
    diff = np.linalg.norm(a1 - a2)
    print(f"两求解器解向量差异: {diff:.2e}")

# 4. 与稠密 LDL^T 在小规模问题上的对比（可选，但作业要求）
# 此处做一个小规模（n=100）的对比，展示稠密无法处理大规模
print("\n" + "="*50)
print("与稠密 LDL^T 求解器对比（小规模 n=100）")
n_small = 100
K_small = diags([-1, 2, -1], [-1, 0, 1], shape=(n_small, n_small), format='csr').toarray()
R_small = np.ones(n_small)
from solver import solve_ldlt
t0 = time.time()
a_small, ok = solve_ldlt(K_small, R_small)
t1 = time.time()
if ok:
    print(f"稠密 LDL^T 求解时间 (n={n_small}): {t1-t0:.4f} 秒")
    r_small = R_small - K_small @ a_small
    rel_res_small = np.linalg.norm(r_small) / np.linalg.norm(R_small)
    print(f"相对残差: {rel_res_small:.2e}")
else:
    print("稠密 LDL^T 分解失败")
print("注意：当 n=5000 时，稠密存储需要内存约 5000^2*8 ≈ 200 MB，但求解时间将远大于稀疏求解器。")