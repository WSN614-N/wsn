import numpy as np
import time
from solver import ldlt_factor, ldlt_solve, solve_ldlt

n = 500
np.random.seed(42)
K = np.random.randn(n, n)
K = K @ K.T + np.eye(n)*10
R1 = np.random.randn(n)
R2 = np.random.randn(n)

t0 = time.time()
a1, ok1 = solve_ldlt(K, R1)
a2, ok2 = solve_ldlt(K, R2)
t1 = time.time()
print(f"两次分别分解+求解: {t1-t0:.4f} s")

t0 = time.time()
L, D = ldlt_factor(K)
a1b = ldlt_solve(L, D, R1)
a2b = ldlt_solve(L, D, R2)
t1 = time.time()
print(f"一次分解+两次回代: {t1-t0:.4f} s")