#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np

# ========== LDL^T 分解与求解函数（完全自行实现） ==========
def ldlt_factor(K):
    """
    对对称正定矩阵 K 进行 LDL^T 分解
    返回 L (单位下三角) 和 D (对角矩阵元素)
    若检测到 D[j] <= 0，抛出 ValueError
    """
    n = K.shape[0]
    # 拷贝矩阵，避免修改原矩阵
    A = K.copy().astype(np.float64)
    L = np.eye(n)
    D = np.zeros(n)
    
    for j in range(n):
        D[j] = A[j, j]
        if D[j] <= 1e-15:
            raise ValueError(f"矩阵非正定或存在零主元：D[{j}] = {D[j]} <= 0")
        # 计算 L[i, j] for i > j
        for i in range(j+1, n):
            L[i, j] = A[i, j] / D[j]
        # 更新 A 的下三角部分（利用对称性）
        for i in range(j+1, n):
            for k in range(j+1, i+1):
                A[i, k] -= L[i, j] * A[k, j]
    return L, D

def ldlt_solve(L, D, R):
    """
    解 LDL^T a = R
    前代：L y = R
    对角：D z = y
    回代：L^T a = z
    """
    n = L.shape[0]
    # 前代
    y = np.zeros(n)
    for i in range(n):
        s = R[i]
        for j in range(i):
            s -= L[i, j] * y[j]
        y[i] = s
    # 对角
    z = y / D
    # 回代
    a = np.zeros(n)
    for i in range(n-1, -1, -1):
        s = z[i]
        for j in range(i+1, n):
            s -= L[j, i] * a[j]
        a[i] = s
    return a

def solve_ldlt(K, R):
    """
    使用 LDL^T 求解 K a = R
    返回 (a, success)  success=True 表示求解成功
    若分解失败，success=False，a 为 None
    """
    try:
        L, D = ldlt_factor(K)
        a = ldlt_solve(L, D, R)
        return a, True
    except ValueError as e:
        print("LDL^T 分解失败:", e)
        return None, False

# ========== 缩减方程求解（与 2.3 作业接口） ==========
def solve_reduction(model, fixed_dof, fixed_value, force_dof, force_value):
    """
    用缩减法求解总体刚度方程
    使用自行实现的 LDL^T 求解器，不调用任何现成求解函数
    """
    # 转换为0索引
    fixed_dof = np.array(fixed_dof) - 1
    force_dof = np.array(force_dof) - 1
    model.nd = len(fixed_dof)
    
    # 构建总体载荷向量
    model.f = np.zeros(model.neq, dtype=np.float64)
    model.f[force_dof] = force_value
    
    # 划分已知和未知自由度
    free_dof = np.setdiff1d(np.arange(model.neq), fixed_dof)
    
    # 分块矩阵
    K_FF = model.K[np.ix_(free_dof, free_dof)]
    K_EF = model.K[np.ix_(fixed_dof, free_dof)]
    f_F = model.f[free_dof]
    d_E = np.array(fixed_value, dtype=np.float64)
    
    # 右端项
    rhs = f_F - K_EF.T @ d_E
    
    # ----- 使用 LDL^T 求解（无回退）-----
    d_F, success = solve_ldlt(K_FF, rhs)
    if not success:
        # 直接抛出异常，不允许继续求解
        raise RuntimeError("LDL^T 分解失败，矩阵可能非正定。求解终止。")
    
    # 重构完整位移向量
    model.d = np.zeros(model.neq, dtype=np.float64)
    model.d[fixed_dof] = d_E
    model.d[free_dof] = d_F
    
    # 计算约束反力
    model.reaction = model.K[fixed_dof, :] @ model.d - model.f[fixed_dof]
    
    # 输出缩减方程的数值质量（仅用于分析，不影响求解）
    r = rhs - K_FF @ d_F
    rel_res = np.linalg.norm(r) / (np.linalg.norm(rhs) + 1e-15)
    print(f"\n缩减方程相对残差: {rel_res:.2e}")
    if K_FF.shape[0] <= 100:
        cond = np.linalg.cond(K_FF)
        print(f"缩减方程条件数: {cond:.2e}")
    else:
        print("矩阵规模较大，跳过条件数计算")
    
    det_KFF = np.linalg.det(K_FF)
    print(f"施加边界条件后缩减矩阵行列式: {det_KFF:.4e}")
    print(f"缩减矩阵非奇异: {abs(det_KFF) > 1e-9}")