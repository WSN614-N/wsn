import numpy as np
from solver import solve_ldlt   # 使用你的 LDL^T 求解器

# 构造标准病态矩阵
K = np.array([[1.0, 1.0],
              [1.0, 1.0001]], dtype=np.float64)
a_exact = np.array([1.0, 1.0])
R = K @ a_exact

print("=" * 50)
print("任务2：病态线性方程组分析")
print("=" * 50)

# 1. 双精度计算
print("\n【双精度 float64】")
a_double, ok = solve_ldlt(K, R)
if ok:
    r = R - K @ a_double
    rel_res = np.linalg.norm(r) / np.linalg.norm(R)
    rel_err = np.linalg.norm(a_double - a_exact) / np.linalg.norm(a_exact)
    cond = np.linalg.cond(K)
    print(f"数值解: {a_double}")
    print(f"相对误差: {rel_err:.2e}")
    print(f"相对残差: {rel_res:.2e}")
    print(f"条件数: {cond:.2e}")
else:
    print("LDL^T 分解失败")

# 2. 四舍五入到4位有效数字（模拟低精度输入）
# 注意：np.round(..., 4) 是保留4位小数，但有效数字是4位需要更精细处理。
# 为简单且符合题意，直接保留4位小数（对于1.0001仍为1.0001，无变化）。
# 更好的方式是转换为 float16（约3-4位有效数字）。
print("\n【4位有效数字模拟 (float16)】")
K_f16 = K.astype(np.float16)
R_f16 = R.astype(np.float16)
a_f16, ok = solve_ldlt(K_f16, R_f16)
if ok:
    # 注意：float16 运算结果会自动提升为 float32 或 float64，需转回 float16 再比较
    a_f16 = a_f16.astype(np.float16)
    r_f16 = R_f16 - K_f16 @ a_f16
    rel_res_f16 = np.linalg.norm(r_f16.astype(np.float64)) / np.linalg.norm(R_f16.astype(np.float64))
    rel_err_f16 = np.linalg.norm(a_f16.astype(np.float64) - a_exact) / np.linalg.norm(a_exact)
    print(f"数值解 (float16): {a_f16}")
    print(f"相对误差: {rel_err_f16:.2e}")
    print(f"相对残差: {rel_res_f16:.2e}")
else:
    print("LDL^T 分解失败")

# 3. 单精度计算
print("\n【单精度 float32】")
K_f32 = K.astype(np.float32)
R_f32 = R.astype(np.float32)
a_f32, ok = solve_ldlt(K_f32, R_f32)
if ok:
    r_f32 = R_f32 - K_f32 @ a_f32
    rel_res_f32 = np.linalg.norm(r_f32) / np.linalg.norm(R_f32)
    rel_err_f32 = np.linalg.norm(a_f32 - a_exact) / np.linalg.norm(a_exact)
    print(f"数值解: {a_f32}")
    print(f"相对误差: {rel_err_f32:.2e}")
    print(f"相对残差: {rel_res_f32:.2e}")
    cond_f32 = np.linalg.cond(K_f32)
    print(f"条件数 (float32): {cond_f32:.2e}")
else:
    print("LDL^T 分解失败")