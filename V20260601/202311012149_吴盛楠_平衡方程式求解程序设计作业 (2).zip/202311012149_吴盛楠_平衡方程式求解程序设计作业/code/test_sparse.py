import numpy as np
import time
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve

# 尝试导入 pypardiso（可选）
try:
    from pypardiso import spsolve as pardsolve
    HAS_PARDISO = True
    print("pypardiso 可用")
except ImportError:
    HAS_PARDISO = False
    print("pypardiso 未安装，只用 scipy.sparse")

# 创建大规模稀疏三对角矩阵
n = 2000
print(f"\n生成 {n}x{n} 稀疏矩阵...")
K = diags([-1, 2, -1], [-1, 0, 1], shape=(n, n), format='csr')
R = np.ones(n)

# 1. 使用 scipy 的求解器
print("\n=== scipy.sparse.linalg.spsolve ===")
t0 = time.time()
a1 = spsolve(K, R)
t1 = time.time()
r1 = R - K @ a1
rel_res1 = np.linalg.norm(r1) / np.linalg.norm(R)
print(f"求解时间: {t1-t0:.4f} 秒")
print(f"相对残差: {rel_res1:.2e}")

# 2. 如果可用，使用 pypardiso
if HAS_PARDISO:
    print("\n=== pypardiso ===")
    t0 = time.time()
    a2 = pardsolve(K, R)
    t1 = time.time()
    r2 = R - K @ a2
    rel_res2 = np.linalg.norm(r2) / np.linalg.norm(R)
    print(f"求解时间: {t1-t0:.4f} 秒")
    print(f"相对残差: {rel_res2:.2e}")