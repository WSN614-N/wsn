import numpy as np
import time
from solver import solve_ldlt

ns = [10, 100, 500, 1000]
print("n\t时间(s)\t相对误差")
for n in ns:
    K = np.zeros((n, n))
    for i in range(n):
        K[i,i] = 2.0
        if i>0:
            K[i,i-1] = -1.0
            K[i-1,i] = -1.0
    a_exact = np.ones(n)
    R = K @ a_exact
    t0 = time.time()
    a, ok = solve_ldlt(K, R)
    t1 = time.time()
    if ok:
        err = np.linalg.norm(a - a_exact) / np.linalg.norm(a_exact)
        print(f"{n}\t{t1-t0:.4f}\t{err:.2e}")
    else:
        print(f"{n}\t分解失败")