import numpy as np
from solver import solve_ldlt

K = np.array([[1,2],[2,1]], dtype=float)
R = np.array([1,1])
a, ok = solve_ldlt(K, R)
if ok:
    print("错误：非正定矩阵却被认为求解成功")
else:
    print("正确：检测到非正定矩阵，返回失败")